﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace VClassLibrary
{
    public class Sql : DbContext
    {
        private static string connection_string = "Server=localhost; User ID=root; Password=; Database=logentries";
        public Sql() : base(new DbContextOptionsBuilder().UseMySql(connection_string, ServerVersion.AutoDetect(connection_string)).Options)
            {
            this.Database.EnsureCreated();
            }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
        }
        public DbSet <LogEntry> logentries { get; set; }
    }
}
