﻿namespace VClassLibrary
{
    public class Class1
    {

    }
}