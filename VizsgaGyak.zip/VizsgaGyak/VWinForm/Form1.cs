using System.Data;
using VClassLibrary;

namespace VWinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DataTable dt = new DataTable();
            dt.Columns.Add("id", typeof(int));
            dt.Columns.Add("CorrelationId", typeof(string));
            dt.Columns.Add("DateUtc", typeof(DateTime));
            dt.Columns.Add("Thread", typeof(int));
            dt.Columns.Add("Level", typeof(string));
            dt.Columns.Add("Logger", typeof(string));
            dt.Columns.Add("Message", typeof(string));
            dt.Columns.Add("Exception", typeof(string));

            int errorszam = 0;
            int sorszam = 0;
            int debugszam = 0;

            using (Sql adatdb = new Sql())
            {
                errorszam = adatdb.logentries.Count(x => x.Level == "Error");
                debugszam = adatdb.logentries.Count(x => x.Level == "Debug");
                sorszam = adatdb.logentries.Count();

                foreach (var entry in adatdb.logentries)
                {
                    dt.Rows.Add(entry.Id, entry.CorrelationId, entry.DateUtc, entry.Thread, entry.Level, entry.Logger, entry.Message, entry.Exception);

                }
            }
            dataGridView1.DataSource = dt;
            label2.Text = $"{sorszam}";
            label4.Text = $"{errorszam}";
            label6.Text = $"{debugszam}";

            comboBox1.DataSource = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName).ToList();


        }


        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}